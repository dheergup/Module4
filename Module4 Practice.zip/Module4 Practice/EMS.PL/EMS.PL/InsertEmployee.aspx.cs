﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    public partial class InsertEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"];
                Master.LogoutVisible = true;
                Master.MenuVisible = true;
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try 
            {
                Employee emp = new Employee();
                emp.EmployeeID = Convert.ToInt32(txtEmpID.Text);
                emp.EmployeeName = txtName.Text;
                emp.Phone = txtPhone.Text;
                emp.Email = txtEmail.Text;
                emp.Location = ddlLocation.SelectedItem.Text;

                int recordsAffected = EmployeeValidation.InsertEmployee(emp);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Record added successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Record Not added");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}