﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class ModelBindingDemo : System.Web.UI.Page
{
    public List<Student> FetchAllStudents()
    {
        DataTable dt = new DataTable();
        SqlConnection con = new SqlConnection();
        con.ConnectionString = ConfigurationManager.ConnectionStrings["StudentConStr"].ConnectionString;
        SqlDataAdapter adap = new SqlDataAdapter("Select * from [dbo].[Student]",con);
        //adap.SelectCommand.CommandText = "Select * from [dbo].[Student]";
        //adap.SelectCommand.Connection = con;
        DataSet ds = new DataSet();
        adap.Fill(ds,"Stud");
        //return ds.Tables["Stud"];
        List<Student> mystud = new List<Student>();
        foreach (DataRow item in ds.Tables[0].Rows)
        {
            Student s1 = new Student();
            s1.StudentID =Int32.Parse( item[0].ToString());
            s1.StudentName = (item[1].ToString());
            s1.City = (item[2].ToString());
            mystud.Add(s1);
        }
        return mystud;
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}