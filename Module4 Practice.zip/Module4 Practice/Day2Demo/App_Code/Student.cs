﻿using System;
using System.Collections.Generic;
using System.Web;

/// <summary>
/// Summary description for Student
/// </summary>
public class Student
{
    public Student()
    {

    }
    public int StudentID { get; set; }
    public string StudentName { get; set; }
    public string City { get; set; }
}