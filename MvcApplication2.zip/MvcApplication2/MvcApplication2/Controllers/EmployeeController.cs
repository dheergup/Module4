﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication2.Models;

namespace MvcApplication2.Controllers
{
    public class EmployeeController : Controller
    {
        private TrainingEntities db = new TrainingEntities();

        //
        // GET: /Employee/

        public ActionResult Index()
        {
            return View(db.Employee_115022.ToList());
        }

        //
        // GET: /Employee/Details/5

        public ActionResult Details(int id = 0)
        {
            Employee_115022 employee_115022 = db.Employee_115022.Find(id);
            if (employee_115022 == null)
            {
                return HttpNotFound();
            }
            return View(employee_115022);
        }

        //
        // GET: /Employee/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Employee/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee_115022 employee_115022)
        {
            if (ModelState.IsValid)
            {
                db.Employee_115022.Add(employee_115022);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(employee_115022);
        }

        //
        // GET: /Employee/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Employee_115022 employee_115022 = db.Employee_115022.Find(id);
            if (employee_115022 == null)
            {
                return HttpNotFound();
            }
            return View(employee_115022);
        }

        //
        // POST: /Employee/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Employee_115022 employee_115022)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee_115022).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employee_115022);
        }

        //
        // GET: /Employee/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Employee_115022 employee_115022 = db.Employee_115022.Find(id);
            if (employee_115022 == null)
            {
                return HttpNotFound();
            }
            return View(employee_115022);
        }

        //
        // POST: /Employee/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee_115022 employee_115022 = db.Employee_115022.Find(id);
            db.Employee_115022.Remove(employee_115022);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Search(string city)
        {
            var query = from a in db.Employee_115022
                        where a.Location == city
                        select a;
            return View(query);
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}