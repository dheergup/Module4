﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EMS.Entity;
using EMS.Exception;

namespace EMS.DAL
{
    public class EmployeeOperations
    {
        public static int InsertEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try 
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "usp_InsertEmployee_115022";

                cmd.Parameters.AddWithValue("@EmpID", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@EmpName", emp.EmployeeName);
                cmd.Parameters.AddWithValue("@Phone", emp.Phone);
                cmd.Parameters.AddWithValue("@Email", emp.Email);
                cmd.Parameters.AddWithValue("@Location", emp.Location);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "usp_UpdateEmployee_115022";

                cmd.Parameters.AddWithValue("@EmpID", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@EmpName", emp.EmployeeName);
                cmd.Parameters.AddWithValue("@Phone", emp.Phone);
                cmd.Parameters.AddWithValue("@Email", emp.Email);
                cmd.Parameters.AddWithValue("@Location", emp.Location);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteEmployee(int empID)
        {
            int recordAffected = 0;

            try 
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "usp_DeleteEmployee";
                cmd.Parameters.AddWithValue("@EmpID", empID);

                cmd.Connection.Open();
                recordAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordAffected;
        }

        public static DataTable DisplayEmployee()
        {
            DataTable dt = new DataTable();

            try 
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "usp_DisplayEmployee";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                else
                {
                    throw new EmployeeException("Employee Data not Available");
                }
                cmd.Connection.Close();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
         
            return dt;
        }

        public static Employee SearchEmployee(int empID)
        {
            Employee emp = null;

            try 
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "usp_SearchEmployee";

                cmd.Parameters.AddWithValue("@EmpID", empID);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    emp = new Employee();
                    emp.EmployeeID = Convert.ToInt32(dr["EmpID"]);
                    emp.EmployeeName = dr["EmpName"].ToString();
                    emp.Phone = dr["Phone"].ToString();
                    emp.Email = dr["Email"].ToString();
                    emp.Location = dr["Location"].ToString();
                }
                else
                {
                    throw new EmployeeException("Employee not found with id" + empID);
                }
                cmd.Connection.Close();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emp;
        }
    }
}
